# Como ejecutar el proyecto

## 1. Install
`npm install`

## 2. Transpilar
`npm run build`

